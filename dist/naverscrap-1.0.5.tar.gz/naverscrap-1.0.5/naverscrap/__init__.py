from naverscrap.naverscrap import NaverScrap
